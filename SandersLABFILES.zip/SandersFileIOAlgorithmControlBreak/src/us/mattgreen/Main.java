package us.mattgreen;



public class Main {

    private final static FileInput movieRatingFile = new FileInput("movieStats.csv");

    public static void main(String[] args) {
        String line;
        String[] fields;
        String[] movieList = new String[100];
        int[] counterMovie = new int[100];
        int[] ratingCount = new int[100];

        while ((line = movieRatingFile.fileReadLine()) != null) {
            fields = line.split(",");

            int movieRating = Integer.parseInt(fields[1]);
            String nMovie = fields[0];
            for (int i = 0; i < movieList.length; i++) {
                if (movieList[i] == null) {
                    movieList[i] = nMovie;
                    ratingCount[i] = movieRating;
                    counterMovie[i] = 1;
                    i = movieList.length;

                } else if (movieList[i].equals(nMovie)) {
                    counterMovie[i]++;
                    ratingCount[i] += movieRating;
                    i = movieList.length;
                }
            }
        }

        for(int i = 0; i<movieList.length; i++){
            if(movieList[i] == null){
                i = movieList.length;
            }else{
                System.out.println("Movie Name: " + movieList[i]  + " | Rating: "+ ratingCount[i]/counterMovie[i] + " | Count: " + counterMovie[i]);
            }
        }


    }
}