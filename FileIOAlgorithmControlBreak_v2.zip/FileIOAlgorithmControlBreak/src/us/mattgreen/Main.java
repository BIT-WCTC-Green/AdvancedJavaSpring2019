package us.mattgreen;

import java.util.Scanner;



public class Main {

    private final static FileInput meals = new FileInput("meals_data.csv");

    public static void main(String[] args) {
        String line;
        String[] fields;
        double average = 0;
        int total = 0;
        int count = 0;
        int grandTotal = 0;
        int grandCount = 0;
        int max = 0;
        int min = 0;
        //String meal = "NA";
        int[] imeal;
        String oldMealType = "NA";
        System.out.format("%-15s   %-15s   %-15s   %-15s   %-15s\n","Meal Type", "Average Calories", "Minimum", "Maximum", "Total");
        System.out.format("%-15s  %-15s   %-15s   %-15s   %-15s\n","==============", "===============", "===============", "===============", "===============");

        //This is the only way I could get any individual meals to print out.  However, only one meal shows
        while ((line = meals.fileReadLine()) != null) {
            fields = line.split(",");
            if (!oldMealType.equals(fields[0])) {
                if (!oldMealType.equals("NA")) {
                    average = total / (double)count;

                    if (max < Integer.parseInt(fields[2])) max = Integer.parseInt(fields[2]);
                    if (min > Integer.parseInt(fields[2])) min = Integer.parseInt(fields[2]);
                    System.out.format("%-20s %4.2f              %d               %d               %-20s\n",oldMealType, average, min, max, total);

                }
                oldMealType = fields[0];


                count = 0;
                total = 0;
            }
            total += Integer.parseInt(fields[2]);
            count++;
            grandTotal += Integer.parseInt(fields[2]);
            grandCount++;
        }
        average = total / count;

        double totalAverage = grandTotal / (double)grandCount;
        System.out.format("%-20s %4.2f            %d                 %d                  %-20s\n",oldMealType, average, min, max, total);
        //System.out.format("%4.2f               %-20s\n", average, total);
        System.out.format("%-15s  %-15s %-15s\n","==============", "===============", " ===============", "===============", "===============");
        System.out.format("%-20s %4.2f         %-20s","Grand Total", totalAverage, total);

    }//end main
}