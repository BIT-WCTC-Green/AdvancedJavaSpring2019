package com.company;

public interface Weighable {
    void addWeight(double pounds);
    void loseWeight(double pounds);


}
