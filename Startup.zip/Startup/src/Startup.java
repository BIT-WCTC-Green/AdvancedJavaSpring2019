import java.util.ArrayList;

/**
    @ author Theresa Bollhagen
 */

public class Startup {

    public static void main (String[] args){

        Person person = new Person();

        String fName;
        String lName;
        int age;

        ArrayList<Person> personList = new ArrayList<Person>();

        //add
        person = new Person();
        person.setPerson("Bruce", "Wayne", "Batman", 34);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Christopher", "Reeves", "Superman", 35);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Linda", "Carter", "Wonderwoman", 26);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Doctor", "Who", "Time Traveler", 900);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Xena", " ", "Warrior Princess", 25);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Jack", "Skellington", "Halloween Performer", 153);
        person.getPerson();
        personList.add(person);

        person  = new Person();
        person.setPerson("Illidan", "Stormrage", "Demon Hunter", 30000);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Lor'themar", "Theron", "Regent Lord", 534);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Felix", "Ungar", "Clean Freak", 46);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Sherlock", "Holmes", "Detective", 35);
        person.getPerson();
        personList.add(person);

        person = new Person();
        person.setPerson("Cup", "O'Soup", "Lunch", 1);
        person.getPerson();
        personList.add(person);

//iterate over arrayList
        for (int i = 0; i < personList.size(); i++){
            Person p = personList.get(i);
            System.out.println(p + "\n");
        }


    }
}
