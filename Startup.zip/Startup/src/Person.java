public class Person extends Startup{


    String firstName;
    String lastName;
    String jobTitle;
    int age;

    public void Person(String fn, String ln, String jt, int ag){
        firstName = fn;
        lastName = ln;
        jobTitle = jt;
        age = ag;
    }

    /**
     *
     */

    public void setPerson() {
        setPerson(firstName, lastName , jobTitle, age );
    }

    /**
     *
     * @param f
     * @param l
     * @param a
     * @param j
     */

    public void setPerson (String f, String l, String j, int a){
        firstName = f;
        lastName = l;
        jobTitle = j;
        age = a;
    }

    public String getPerson(){
       return firstName + " " + lastName + " " + jobTitle + " " + age;

    }
    @Override
    public String toString(){
        String s = "Name: " + firstName + " " + lastName + "\t" + "Job Title: " +
                jobTitle + "\t" + "Age: " + age;
        return s;
    }



}//end public class person

