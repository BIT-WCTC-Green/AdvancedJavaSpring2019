public class Person {
    Private String firstName;





    public Person(){



    }


}
