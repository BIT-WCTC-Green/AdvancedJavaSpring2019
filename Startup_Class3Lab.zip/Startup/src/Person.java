public class Person implements Weighable {


    protected String firstName;
    protected String lastName;
    protected String character;
    protected int age;
    protected String type;





    /**
     *
     */

    public void setPerson() {
        setPerson(firstName, lastName , character, age);
    }

    /**
     *
     * @param f
     * @param l
     * @param a
     * @param c
     *
     */

    public void setPerson (String f, String l, String c, int a){
        firstName = f;
        lastName = l;
        character = c;
        age = a;

    }

    public String getPerson(){
       return this.firstName + " " + this.lastName + " " + this.character + " " + this.age + " " + "type";

    }

    public Person(String fn, String ln, String ch, int ag){
        firstName = fn;
        lastName = ln;
        character = ch;
        age = ag;

    }

    public void type(){
        type = "NA";
    }
    @Override
    public String toString(){
        String s = "Name: " + this.firstName + " " + this.lastName + "\t" + "Character: " +
                this.character + "\t" + "Age: " + age + "\t" + type;
        return s;
    }





}//end public class person

