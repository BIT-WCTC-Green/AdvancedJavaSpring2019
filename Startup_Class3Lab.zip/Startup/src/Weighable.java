public interface Weighable {

    public void addWeight();
    public void loseWeight();
}
