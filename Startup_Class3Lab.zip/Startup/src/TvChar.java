public class TvChar extends Person{

    String firstName;
    String lastName;
    String character;
    int age;
    String type;

    public TvChar(String fn, String ln, String ch, int ag) {

        super(fn, ln, ch, ag);
    }



    public void type(){

        type = "TV Character";
    }

    public String toString(){
        String s = "Name: " + firstName + " " + lastName + "\t" + "Character: " +
                character + "\t" + "Age: " + age + "\t" + type;
        return s;
    }

    @Override
    public void addWeight() {
        double addW;

    }

    @Override
    public void loseWeight() {
        double loseW;
    }
}
